/**
* Phaticusthiccy Emacs-Train @2021 
* All Right Reserved
*/

public class Phaticusthiccy {
  
  public static void main(String[] args) {
    
    System.out.println("This is Thiccy. 17 Years Old AI Developer.");
    
  }
  
}

/**
* >> This is Thiccy. 17 Years Old AI Developer.
*/
