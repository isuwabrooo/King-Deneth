# Java-Train

## Information ℹ️
Experimental  / Templates / Training Repository for Java Language

##

## Template 💬
Output Datas / Trainings / Basic Functions 
